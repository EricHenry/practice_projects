from distutils.core import setup

setup(
	name			= 'nester',
	version			= '1.0.0',
	py_modules		= ['nester'],
	author			= 'CoreDev',
	author_email	= 'correia.eh@gmail.com',
	url				= 'workingOnIt',
	description		= 'A simple printer of nested lists',
	);